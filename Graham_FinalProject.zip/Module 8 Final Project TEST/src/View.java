import java.util.Scanner;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.io.FileWriter;
import java.util.*;
 

public class View extends Main { 
	
	public static void pickView(ArrayList entries) throws java.io.IOException { //This block will open created file to read all data from it 
		java.io.File file = new java.io.File("entries.txt");
		Scanner myReader = new Scanner(file);
		PrintWriter output = new PrintWriter(new FileWriter("entries.txt", true));
		
		while(myReader.hasNext()) {
			String read = myReader.nextLine();
			System.out.println(read);
		}
	}
}