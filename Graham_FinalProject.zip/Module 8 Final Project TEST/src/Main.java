/* Josh Graham
 * Java
 * FoodTracker(TM) custom program to track details about food
 * Date last updated: 12/15/22
 */

import java.util.Scanner; //For whatever reason eclipse keeps autohiding my header. If that happens, clicking on it seems to pull the rest of it up.
import java.io.PrintWriter;
import java.util.ArrayList;
import java.io.FileWriter;
import java.util.GregorianCalendar;
import java.util.*;

public class Main {

	public static void main(String[] args) throws java.io.IOException {
		
		int selection = 0; //This entire block is dedicated to variable declaration
		int cals = 0;
		int sodium = 0;
		int totalSugars = 0;
		int addedSugars = 0;
		int totalFat = 0;
		int protein = 0;
		int potassium = 0;
		int fiber = 0;
		int exitCondition = 3;
		GregorianCalendar calendar = new GregorianCalendar();
		int year = calendar.get(GregorianCalendar.YEAR);
		int month = calendar.get(GregorianCalendar.MONTH);
		int day = calendar.get(GregorianCalendar.DAY_OF_MONTH);
		boolean continueInput = true;
		ArrayList<Entry> entries = new ArrayList<Entry>(); //Created an ArrayList so that the program could add more array space as needed rather than just assigning a large number or something
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Welcome to HealthTracker(TM)!");
		
		while(exitCondition != 0) { //Program will run as many times as user desires as long as sentinel value is not provided
			java.io.File file = new java.io.File("entries.txt");
			Scanner myReader = new Scanner(file);
			PrintWriter output = new PrintWriter(new FileWriter("entries.txt", true));
			do { //This will be the setup for every user input operation. Do/try so to ensure that the program does not crash while getting input
				try {
					System.out.println("Select '1' if you would like to add a new entry. Select '2' if you would like to view a previous entry.");
					selection = scanner.nextInt();
					if((selection != 1) && (selection != 2)) {
						System.out.println("You entered an invalid selection. Please try again.");
					} else {
						continueInput = false;
					}
				}
				catch (InputMismatchException ex) {
					System.out.println("Invalid input. An integer is required.");
					scanner.nextLine(); //This is present in all of these catches just to clear the input stream
				}
			} while(continueInput);
			continueInput = true; //I also have this so that the program doesn't accidentally enter any unintended if statements
			
			if(selection == 1) {
				do {
					try {
						System.out.println("How many calories did you have today?");
						cals = scanner.nextInt();
						continueInput = false;
					}
					catch (InputMismatchException ex) {
						System.out.println("Invalid input. An integer is required.");
						scanner.nextLine();
					}
				} while(continueInput);
					continueInput = true;
			
				do {
					try {
						System.out.println("How much sodium did you have today(in milligrams)?");
						sodium = scanner.nextInt();
						continueInput = false;
					}
					catch (InputMismatchException ex) {
						System.out.println("Invalid input. An integer is required.");
						scanner.nextLine();
					}
				} while(continueInput);
					continueInput = true;
						
				do {
					try {
						System.out.println("How much sugar did you have today(in grams)?");
						totalSugars = scanner.nextInt();
						continueInput = false;
					}
					catch (InputMismatchException ex) {
						System.out.println("Invalid input. An integer is required.");
						scanner.nextLine();
					}
				} while(continueInput);
					continueInput = true;
					
				do {
					try {
						System.out.println("How many of those sugars were added(in grams)?");
						addedSugars = scanner.nextInt();
						continueInput = false;
					}
					catch (InputMismatchException ex) {
						System.out.println("Invalid input. An integer is required.");
						scanner.nextLine();
					}
				} while(continueInput);
					continueInput = true;
				
				do {
					try {
						System.out.println("How many grams of fat did you have today?");
						totalFat = scanner.nextInt();
						continueInput = false;
					}
					catch (InputMismatchException ex) {
						System.out.println("Invalid input. An integer is required.");
						scanner.nextLine();
					}
				} while(continueInput);
					continueInput = true;
					
				do {
					try {
						System.out.println("How much protein did you have today(in grams)?");
						protein = scanner.nextInt();
						continueInput = false;
					}
					catch (InputMismatchException ex) {
						System.out.println("Invalid input. An integer is required.");
						scanner.nextLine();
					}
				} while(continueInput);
					continueInput = true;
					
				do {
					try {
						System.out.println("How much potassium did you have today(in milligrams)?");
						potassium = scanner.nextInt();
						continueInput = false;
					}
					catch (InputMismatchException ex) {
						System.out.println("Invalid input. An integer is required.");
						scanner.nextLine();
					}
				} while(continueInput);
					continueInput = true;
				
				do {
					try {
						System.out.println("How much dietary fiber did you have today(in grams)?");
						fiber = scanner.nextInt();
						continueInput = false;
					}
					catch (InputMismatchException ex) {
						System.out.println("Invalid input. An integer is required.");
						scanner.nextLine();
					}
				} while(continueInput);
					continueInput = true;
					
				entries.add(new Entry(cals, sodium, totalSugars, addedSugars, totalFat, protein, potassium, fiber)); //This creates a new Entry with given variable values for parameters
				
				output.print("Date: " + month + "/" + day + "/" + year + '\n');
				output.print("Calories: " + cals + '\n'); //These just print out to the file 
				output.print("Sodium: " + sodium + '\n');
				output.print("Total Sugars: " + totalSugars + '\n');
				output.print("Added Sugars: " + addedSugars + '\n');
				output.print("Fat: " + totalFat + '\n');
				output.print("Protein: " + protein + '\n');
				output.print("Potassium: " + potassium + '\n');
				output.println("Fiber: " + fiber + '\n');
				output.close();
			}
			
			else if(selection == 2) {	
				View.pickView(entries);
			}
			
			do {
				try {  
					System.out.println("Would you like to do anything else? Press zero to exit, one to continue.");
					exitCondition = scanner.nextInt();
					if((exitCondition != 0) && (exitCondition != 1)) {
						System.out.println("You entered an invalid selection. Please try again.");
					} else {
						continueInput = false;
					}
				}
				catch(InputMismatchException ex) {
					System.out.println("Invalid input. an integer is required.");
					scanner.nextLine();
				}
			} while(continueInput); //Will continue looping until sentinel value is achieved
				continueInput = true;
		}
		System.out.println("Have a wonderful day!");
	}	
}