import java.util.GregorianCalendar;

public class Entry extends Main {
	private int cals = 0; //This block declares variables
	private int sodium = 0;
	private int totalSugars = 0;
	private int addedSugars = 0;
	private int totalFat = 0;
	private int protein = 0;
	private int potassium = 0;
	private int fiber = 0;
	private int month = 0;
	private int day = 0;
	private int year = 0;
	
	//This block creates new Entry object and sets its specific variables using this keyword
	Entry(int cals, int sodium, int totalSugars, int addedSugars, int totalFat, int protein, int potassium, int fiber) {
		GregorianCalendar calendar = new GregorianCalendar();
		this.year = calendar.get(GregorianCalendar.YEAR);
		this.month = calendar.get(GregorianCalendar.MONTH);
		this.day = calendar.get(GregorianCalendar.DAY_OF_MONTH);
		this.cals = cals;
		this.sodium = sodium;
		this.totalSugars = totalSugars;
		this.addedSugars = addedSugars;
		this.totalFat = totalFat;
		this.protein = protein;
		this.potassium = potassium;
		this.fiber = fiber;
	}
	
	Entry(){ //default constructor
	}
	
	//Early in I created getters and setters for all of my variables. Some I used, some I didn't but I kept everything in in case I wanted to add something that uses them later down the line
	public int getCals() {
		return cals;
	}
	public void setCals(int cals) {
		this.cals = cals;
	}
	public int getSodium() {
		return sodium;
	}
	public void setSodium(int sodium) {
		this.sodium = sodium;
	}
	public int getTotalSugars() {
		return totalSugars;
	}
	public void setTotalSugars(int totalSugars) {
		this.totalSugars = totalSugars;
	}
	public int getAddedSugars() {
		return addedSugars;
	}
	public void setAddedSugars(int addedSugars) {
		this.addedSugars = addedSugars;
	}
	public int getTotalFat() {
		return totalFat;
	}
	public void setTotalFat(int totalFat) {
		this.totalFat = totalFat;
	}
	public int getProtein() {
		return protein;
	}
	public void setProtein(int protein) {
		this.protein = protein;
	}
	public int getPotassium() {
		return potassium;
	}
	public void setPotassium(int potassium) {
		this.potassium = potassium;
	}
	public int getFiber() {
		return fiber;
	}
	public void setFiber(int fiber) {
		this.fiber = fiber;
	}

	public int getMonth() {
		return month + 1;
	}
	public int getDay() {
		return day;
	}
	public int getYear() {
		return year;
	}
}