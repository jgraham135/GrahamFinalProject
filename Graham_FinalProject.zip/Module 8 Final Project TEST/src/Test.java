/*import java.util.Scanner; //For whatever reason eclipse keeps autohiding my header. If that happens, clicking on it seems to pull the rest of it up.
import java.io.PrintWriter;
import java.util.ArrayList;
import java.io.FileWriter;
import java.util.GregorianCalendar;
import java.util.*;

public class Test {
	public static void testProject() throws java.io.IOException {
		Entry testEntry = new Entry(3600, 4000, 30, 18, 25, 31, 4800, 19);
		
		PrintWriter output = new PrintWriter(new FileWriter("entries.txt", true));
		
		output.print(testEntry.getMonth() + '\n');
		output.print(testEntry.getDay() + '\n');
		output.print(testEntry.getYear() + '\n');
		output.print(testEntry.getCals() + '\n');
		output.print(testEntry.getSodium() + '\n');
		output.print(testEntry.getTotalSugars() + '\n');
		output.print(testEntry.getAddedSugars() + '\n');
		output.print(testEntry.getTotalFat() + '\n');
		output.print(testEntry.getProtein() + '\n');
		output.print(testEntry.getPotassium() + '\n');
		output.print(testEntry.getFiber() + '\n');
	}
}*/
